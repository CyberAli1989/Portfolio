window.setTimeout(function(){
    $('.skill-progress').addClass("go");
  }, 1000);